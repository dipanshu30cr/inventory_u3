package com.example.Inventory.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.service.Brand_Service;

@Controller
public class Head_Controller 
{
	
	@Autowired
	private Brand_Service service;
	
	
	@GetMapping("/") // to provide path

	public String home() {
		return "Home"; // this will go to homepage
	}
	
	
	@GetMapping("/brand_mstr")
	public ModelAndView availablebrand()
	{
		//return "availableLaptop";
		List<Brand_Entity> list= service.getAllBrand();
		return new ModelAndView( "Brand_Mht" , "brand" , list );
		
	}
	
	
	@PostMapping("/edit_save")
	public String addBrand(@ModelAttribute Brand_Entity l, Model model)
	
	{	
		System.out.println(l);
		
		if (service.existsByName(l.getName())) {
            model.addAttribute("error", "Brand name already exists. Please choose a different name.");
            return "redirect:/brand_mstr"; }
		
		
		service.save(l);
		return "redirect:/brand_mstr";
	}
	
	@PostMapping("/save")
    public String saveBrand(@ModelAttribute Brand_Entity brand, Model model) {
        // Check if the brand name already exists in the database
        if (service.existsByName(brand.getName())) {
            model.addAttribute("error", "Brand name already exists. Please choose a different name.");
            //return "redirect:/brand_mstr"; // Return to the brand registration page with an error message
            return "AlreadyExists";
        }

        // If the brand name is unique, proceed with saving
        service.save(brand);
        return "redirect:/brand_mstr"; // Redirect to the home page or any other appropriate page
    }



	
	@GetMapping("/brand_register")             //this page is created inside template html
	public String BrandRegister()
	{
		return "Brand_Register";               //this is in brand_mht html file
	}
	
	@RequestMapping("/edit_brand{id}")
	public String editLaptop(@PathVariable("id") int id, Model model)
	{	
		Brand_Entity l3= service.getBrandById(id);
		model.addAttribute("brand", l3);
		return "Brand_Edit";
		
	}
	
//	@RequestMapping("/delete_brand/{id}")
//	public String deleteLaptop(@PathVariable("id") int id)
//	{
//		service.deleteByid(id);
//		return "redirect:/brand_mstr";
//		
//	}
//	 @GetMapping("/delete_brand/{id}")
//	    public String deleteBrand(@PathVariable("id") int id) {
//	        service.deleteByid(id);
//	        return "redirect:/brand_mstr";
//	    }
	@PostMapping("/soft_delete_brand/{id}")
    @ResponseBody
    public Map<String, Object> softDeleteBrand(@PathVariable("id") int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            service.softDeleteById(id);
            response.put("success", true);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return response;
    }
	@GetMapping("/checkBrandName")
    @ResponseBody
    public Map<String, Boolean> checkBrandName(@RequestParam String name) {
        boolean exists = service.brandNameExists(name);
        Map<String, Boolean> response = new HashMap<>();
        response.put("exists", exists);
        return response;
    }


}
