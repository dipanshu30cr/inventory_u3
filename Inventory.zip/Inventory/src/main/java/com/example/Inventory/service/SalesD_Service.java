package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseD_Entity;
import com.example.Inventory.entity.SalesD_Entity;
import com.example.Inventory.repository.PurchaseD_Repository;
import com.example.Inventory.repository.SalesD_Repository;

@Service
public class SalesD_Service 
{
	@Autowired
	SalesD_Repository sdrepo;
    
	public void save(SalesD_Entity sde)
	{
		sdrepo.save(sde);
	}
	
	public List<SalesD_Entity> getallsellsdetails()
	{
		return sdrepo.findAll();
	}
	
	
	public SalesD_Entity getbyid(int id)
	{
		return sdrepo.findById(id).get();
	}
	
	public void deleteByid(int id)
	{
		sdrepo.deleteById(id);
	}

	 public boolean isItemAlreadySold(int itemId) {
	        return sdrepo.findByItemId(itemId) != null;
	    }
	 
	 public int getPreviousSalesQuantity(int itemId) {
	        // Logic to fetch the previous sales quantity for the given item ID
	        SalesD_Entity previousSale = sdrepo.findByItemId(itemId);
	        if (previousSale != null) {
	            return previousSale.getQty();
	        } else {
	            return 0; // If there are no previous sales, return 0
	        }
	    }

	
}
