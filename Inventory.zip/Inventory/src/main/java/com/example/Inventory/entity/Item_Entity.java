package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="item_table")
public class Item_Entity 
{
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int item_id;
	private String item_name;
	private String item_code;
	private int price;
	
	@Column(name = "date_time") // Mapping to the database column
    private LocalDateTime datetime;
	
	@Column(nullable = false)
	boolean status=true;
	
	@ManyToOne
	@JoinColumn(name = "brand_id", nullable = false)
    private Brand_Entity brand_id;
	
	@OneToMany(mappedBy = "SDitem_id", cascade= CascadeType.ALL)
    private List<SalesD_Entity> SalesDitem;
    
    @OneToMany(mappedBy = "PDitem_id", cascade= CascadeType.ALL)
    private List<PurchaseD_Entity> PDitem_id;
    

    @OneToMany(mappedBy = "iqd", cascade = CascadeType.ALL)
    private List<ItemQuantityDifference_Entity> iqd;
    
    @OneToMany(mappedBy = "dd", cascade = CascadeType.ALL)
    private List<DateDifference_Entity> dd;
    
    
    
    
    

	public Item_Entity(int item_id, String item_name, String item_code, int price, LocalDateTime datetime, boolean status,
			Brand_Entity brand_id) {
		super();
		this.item_id = item_id;
		this.item_name = item_name;
		this.item_code = item_code;
		this.price = price;
		this.datetime = datetime;
		this.status = status;
		this.brand_id = brand_id;
	}

	public Item_Entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_code() {
		return item_code;
	}

	public void setItem_code(String item_code) {
		this.item_code = item_code;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public LocalDateTime getDatetime() {
		return datetime;
	}

	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Brand_Entity getBrand_id() {
		return brand_id;
	}

	public void setBrand_id(Brand_Entity brand_id) {
		this.brand_id = brand_id;
	}

	@Override
	public String toString() {
		return "Item_Entity [item_id=" + item_id + ", item_name=" + item_name + ", item_code=" + item_code + ", price="
				+ price + ", datetime=" + datetime + ", status=" + status + ", brand_id=" + brand_id + "]";
	}
	
	

}
