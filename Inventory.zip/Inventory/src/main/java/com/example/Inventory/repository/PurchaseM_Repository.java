package com.example.Inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseM_Entity;

@Repository
public interface PurchaseM_Repository   extends JpaRepository<PurchaseM_Entity, Integer>
{
	
	List<PurchaseM_Entity> findByStatusTrue();
}
