package com.example.Inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.PurchaseD_Entity;
import com.example.Inventory.entity.SalesD_Entity;
import com.example.Inventory.repository.PurchaseD_Repository;

@Service
public class PurchaseD_Service {
	
	@Autowired PurchaseD_Repository pdrepo;
	
	public void save(PurchaseD_Entity sde)
	{
		pdrepo.save(sde);
	}
	
	public List<PurchaseD_Entity> getallpurchasedetails()
	{
		return pdrepo.findAll();
	}
	
	
	public PurchaseD_Entity getbyid(int id)
	{
		return pdrepo.findById(id).get();
	}
	
//	public void deleteByid(int id)
//	{
//		pdrepo.deleteById(id);
//	}
	public void deleteByid(int id) {
        PurchaseD_Entity purchaseDetail = getbyid(id);
        purchaseDetail.setStatus(false);
        save(purchaseDetail);
    }
//	public Integer getQuantityByItemId(int itemId) {
//        return pdrepo.findQuantityByItemId(itemId);
//    }
//	public Optional<Integer> getTotalQtyByItemId(int itemId) {
//        return pdrepo.findTotalQtyByItemId(itemId);
//    }


}
