package com.example.Inventory.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class Available_Entity 

{
	@Id
    private int item_id;
	
//	@JoinColumn(name = "a_Itemid", referencedColumnName = "item_id")
//    private Item_Entity a_Itemid;

}
