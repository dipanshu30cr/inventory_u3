package com.example.Inventory.controller;

import java.util.List;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.service.Supplier_Service;

@Controller
public class SupplierM_Controller 
{
	@Autowired
	private Supplier_Service ser;
	
	@GetMapping("/supplier_mstr")
	public ModelAndView availablesupplier()
	{
		//return "availableLaptop";
		List<SupplierM_Entity> list= ser.getAllSupplier();
		return new ModelAndView( "Supplier_Mht" , "supplier" , list );
		
	}
	
	
	
	@PostMapping("/save_supplier")
	public String addSupplier(@ModelAttribute SupplierM_Entity l, Model model)
	{	
		System.out.println(l);
		
		if (ser.existsByMob(l.getMob())) {
            model.addAttribute("error", "Supplier Mobile num already exists. Please choose a different name.");
            return "AlreadyExists"; }
		
		
		ser.save(l);
		return "redirect:/supplier_mstr";
	}
	
	@GetMapping("/supplier_register")             //this is in brand_mht html file
	public String SupplierRegister()
	{
		return "Supplier_Register";    //this page is created inside template html
	}
	/*
	 * @GetMapping("/delete_supplier/{id}") ///delete_supplier/${supplierId} public
	 * String deleteSupplier(@PathVariable("id") int id) { ser.deleteByid(id);
	 * return "redirect:/supplier_mstr"; // Redirect to the supplier management page
	 * }
	 */
	
//	@GetMapping("/delete_salesMaster/{id}")
//	public String deleteSalesMaster(@PathVariable("id") int id) {
//		sa.deleteByid(id);
//		return "redirect:/sale_mstr";
//	}
	
	
	
	@RequestMapping("/edit_supplier{id}")
	public String editSupplier(@PathVariable("id") int id, Model model)
	{	
		SupplierM_Entity l3= ser.getSupplierById(id);
		
//		if (ser.existsByMob(l3.getMob())) {
//            model.addAttribute("error", "Supplier Mobile num already exists. Please choose a different name.");
//            return "AlreadyExists"; }
		
		model.addAttribute("supplier", l3);
		return "Supplier_Edit";
		
	}
	@GetMapping("/delete_supplier/{id}")
    public String softDeleteSupplier(@PathVariable("id") int id) {
        ser.softDeleteSupplier(id);
        return "redirect:/supplier_mstr"; // Redirect to the supplier management page
    }


	
	
	

}
