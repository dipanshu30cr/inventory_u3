package com.example.Inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.entity.SalesM_Entity;
import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.service.SalesM_Service;

@Controller
public class SalesM_Controller 
{
	
	@Autowired
	SalesM_Service sa;
//	@GetMapping("/sale_mstr")
//	public ModelAndView availablesales()                                 //ModelAndView class is used to return both the
//	                                                                    //model (data) and the view (UI template) in a single return value 
//                                                                        // from a controller method.
//	{
//		List<SalesM_Entity> list= sa.getAllSalesM();
//		return new ModelAndView( "SalesM_ht" , "sales" , list );
//	}
//	
	
	@GetMapping("/sale_mstr")
    public ModelAndView availablesales() {
        List<SalesM_Entity> list = sa.getAllSalesM(); // Retrieve active sales records
        return new ModelAndView("SalesM_ht", "sales", list);
    }
	
	@PostMapping("/save_salesM")
	public String addSales(@ModelAttribute SalesM_Entity l, Model model)
	{	
		System.out.println(l);
		
		/*
		 * if (sa.existsByPhn(l.getPhn())) { model.addAttribute("error",
		 * "Sales Master Mobile num already exists. Please choose a different name.");
		 * return "AlreadyExists"; }
		 */
		 if (sa.phoneExistsWithDifferentId(l.getPhn(), l.getSalesMid())) {
		        model.addAttribute("error", "Mobile number already in use with a different record. Please use a different number.");
		        model.addAttribute("sales", l); // Send back the form with the entered data and error message
		        return "SalesM_Edit"; // Redirect back to the edit page
		    }
		sa.save(l);
		return "redirect:/sale_mstr";
	}

	/*
	 * @PostMapping("/edit_master_sales") public String editSales(@ModelAttribute
	 * SalesM_Entity l, Model model) { System.out.println(l);
	 * 
	 * sa.save(l); return "redirect:/sale_mstr"; }
	 */
	@PostMapping("/edit_master_sales")
	public String editSales(@ModelAttribute SalesM_Entity l, Model model) {
	    System.out.println(l);
	    // Check if phone exists with a different ID
	    if (sa.phoneExistsWithDifferentId(l.getPhn(), l.getSalesMid())) {
	        model.addAttribute("error", "Mobile number already in use with a different record. Please use a different number.");
	        model.addAttribute("sales", l); // Send back the form with the entered data and error message
	        return "SalesM_Edit"; // Redirect back to the edit page
	    }
	    sa.save(l);
	    return "redirect:/sale_mstr";
	}
	
	@GetMapping("/sales_register")             //this is in brand_mht html file
	public String SalesMRegister()
	{
		return "SalesM_Register";    //this page is created inside template html
	}
	
//	@GetMapping("/delete_salesDetail/{id}")
//    public String deleteSalesDetails(@PathVariable("id") int id) {
//        sa.deleteByid(id);
//        return "redirect:/sale_details"; // Redirect to the supplier management page
//    }
	
	/*
	 * @GetMapping("/delete_salesMaster/{id}") public String
	 * deleteSalesMaster(@PathVariable("id") int id) { sa.deleteByid(id); return
	 * "redirect:/sale_mstr"; }
	 */
	
	@GetMapping("/delete_salesMaster/{id}")
    public String deleteSalesMaster(@PathVariable("id") int id) {
        SalesM_Entity salesEntity = sa.getSalesMById(id);
        if (salesEntity != null) {
            salesEntity.setStatus(false); // Soft-delete by setting status to false
            sa.save(salesEntity); // Save the updated entity
        }
        return "redirect:/sale_mstr";
    }
	
	
	@RequestMapping("/edit_sales{id}")
	public String editSalesM(@PathVariable("id") int id, Model model)
	{	
		SalesM_Entity l3= sa.getSalesMById(id);
		
//		if (sa.existsByPhn(l3.getPhn())) {
//            model.addAttribute("error", "Sales Master Mobile num already exists. Please choose a different name.");
//            return "AlreadyExists"; }
		model.addAttribute("sales", l3);
		return "SalesM_Edit";
		
	}
	

}
