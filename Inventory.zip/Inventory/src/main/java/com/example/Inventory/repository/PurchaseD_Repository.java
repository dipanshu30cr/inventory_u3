package com.example.Inventory.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.PurchaseD_Entity;

@Repository
public interface PurchaseD_Repository extends JpaRepository<PurchaseD_Entity, Integer>
{

	
	@Query("SELECT SUM(p.qty) FROM PurchaseD_Entity p WHERE p.PDitem_id.item_id = :itemId")
    Integer sumQuantityByItemId(int itemId);
	
	
	
	@Query("SELECT SUM(p.qty) FROM PurchaseD_Entity p WHERE p.PDitem_id.item_id = :itemId AND p.purchaseD_datetime BETWEEN :startDateTime AND :endDateTime")
    Integer sumQuantityByItemIdAndDateTimeRange(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime);


	

	/*
	 * @Query("SELECT pd FROM PurchaseD_Entity pd JOIN FETCH pd.PDitem_id")
	 * List<PurchaseD_Entity> findAllWithItems();
	 */
	
	

}
