//package com.example.Inventory.service;
//
//public class ItemQuantityDifferenceService {
//
//}
package com.example.Inventory.service;

import com.example.Inventory.entity.ItemQuantityDifference_Entity;
import com.example.Inventory.repository.PurchaseD_Repository;
import com.example.Inventory.repository.SalesD_Repository;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemQuantityDifferenceService {

    @Autowired
    private PurchaseD_Repository purchaseDRepository;

    @Autowired
    private SalesD_Repository salesDRepository;

    public int calculateQuantityDifference(int itemId) {
        // Get the purchased quantity
        int purchasedQuantity = purchaseDRepository.sumQuantityByItemId(itemId);

        // Get the sold quantity
        int soldQuantity = salesDRepository.sumQuantityByItemId(itemId);

        // Calculate the difference
        return purchasedQuantity - soldQuantity;
    }
    
}

