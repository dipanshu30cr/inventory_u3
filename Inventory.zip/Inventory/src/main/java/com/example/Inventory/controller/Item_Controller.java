//package com.example.Inventory.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.example.Inventory.entity.Brand_Entity;
//import com.example.Inventory.entity.Item_Entity;
//import com.example.Inventory.service.Brand_Service;
//import com.example.Inventory.service.Item_Service;
//
//import java.util.List;
//
//@Controller
//public class Item_Controller {
//
//    @Autowired
//    private Item_Service itemService;
//    @Autowired
//    private Brand_Service brandService;
//
//    // Mapping to show all items
//    @GetMapping("/item_mstr")
//    public ModelAndView availableItems() {
//        List<Item_Entity> items = itemService.getAllItem();
//        return new ModelAndView("ItemMht", "items", items);
//    }
//    
//    
//    @GetMapping("/check_item_name")
//    @ResponseBody
//    public boolean checkItemName(@RequestParam String itemName, @RequestParam int brandId) {
//        return itemService.existsByItemNameAndBrandId(itemName, brandId);
//    }
//    
//    // Mapping to add a new item
//    @PostMapping("/save_item")
//    public String addItem(@ModelAttribute Item_Entity item, Model model) {
//        System.out.println(item);
//        itemService.save(item);
//        return "redirect:/item_mstr"; // Redirect to refresh the item list
//    }
//    
//    @GetMapping("/item_quantity_difference")
//    public String itemQuantityDifference(Model model) {
//        List<Item_Entity> items = itemService.getAllItem(); // Fetch all items from the database
//        model.addAttribute("items", items); // Add the list of items to the model
//        return "ItemQuantityDifference"; // Return the template name
//    }
//
//    
//    @GetMapping("/item_register")
//    public ModelAndView itemRegister() {
//        List<Brand_Entity> activeBrands = brandService.getActiveBrands();
//        ModelAndView mav = new ModelAndView("Item_Register");
//        mav.addObject("brands", activeBrands);
//        mav.addObject("item", new Item_Entity());
//        return mav;
//    }
//    
//   
//    @GetMapping("/delete_item/{itemId}")
//    public String deleteItem(@PathVariable("itemId") int id) {
//        itemService.deleteByid(id);
//        return "redirect:/item_mstr";
//    }
//    
//    @RequestMapping("/edit_item{id}")
//    public String showEditForm(@PathVariable("id") int id, Model model) {
//        Item_Entity item = itemService.getItemById(id);
//        model.addAttribute("item", item);
//        model.addAttribute("brands", brandService.getAllBrand());
//        return "item_edit";
//    }
//
//    @PostMapping("/update_save")
//    public String updateItem(@ModelAttribute("item") Item_Entity item) {
//        // Ensure the item ID is set, indicating an existing item
//        itemService.saveItem(item);  // Ensure this actually updates the item in the database
//        return "redirect:/item_mstr";  // Redirect to the item list page after updating
//    }
//    
//    
//}
package com.example.Inventory.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.service.Brand_Service;
import com.example.Inventory.service.Item_Service;

import java.util.List;

@Controller
public class Item_Controller {

    @Autowired
    private Item_Service itemService;
    @Autowired
    private Brand_Service brandService;

	/*
	 * @GetMapping("/item_mstr") public ModelAndView availableItems() {
	 * List<Item_Entity> items = itemService.getActiveService(); return new
	 * ModelAndView("ItemMht", "items", items); }
	 */
    
    @GetMapping("/item_mstr")
    public ModelAndView availableItems() {
        List<Item_Entity> items = itemService.getAllItem(); // Fetch all items, including soft-deleted ones
        return new ModelAndView("ItemMht", "items", items);
    }

    @GetMapping("/check_item_name")
    @ResponseBody
    public boolean checkItemName(@RequestParam String itemName, @RequestParam int brandId) {
        return itemService.existsByItemNameAndBrandId(itemName, brandId);
    }

    @PostMapping("/save_item")
    public String addItem(@ModelAttribute Item_Entity item, Model model) {
        if (itemService.existsByItemNameAndBrandId(item.getItem_name(), item.getBrand_id().getId())) {
            model.addAttribute("errorMessage", "Item name already exists for the selected brand.");
            return "Item_Register"; // Show the registration form again with error message
        }
        itemService.save(item);
        return "redirect:/item_mstr"; // Redirect to refresh the item list
    }

//    @GetMapping("/delete_item/{itemId}")
//    public String deleteItem(@PathVariable("itemId") int id) {
//        itemService.deleteByid(id);
//        return "redirect:/item_mstr";
//    }
    @GetMapping("/delete_item/{itemId}")
    public String softDeleteItem(@PathVariable("itemId") int id) {
        Item_Entity item = itemService.getItemById(id);
        if (item != null) {
            // Update the status to indicate soft deletion
            item.setStatus(false); // Assuming 0 indicates soft deletion
            itemService.save(item); // Update the item in the database
        }
        return "redirect:/item_mstr";
    }


    @GetMapping("/edit_item{id}")
    public String showEditForm(@PathVariable("id") int id, Model model) {
        Item_Entity item = itemService.getItemById(id);
        model.addAttribute("item", item);
        model.addAttribute("brands", brandService.getAllBrand());
        return "item_edit";
    }

    @PostMapping("/update_save")
    public String updateItem(@ModelAttribute("item") Item_Entity item) {
        itemService.saveItem(item);
        return "redirect:/item_mstr";
    }
    @GetMapping("/item_register")
  public ModelAndView itemRegister() {
      List<Brand_Entity> activeBrands = brandService.getActiveBrands();
      ModelAndView mav = new ModelAndView("Item_Register");
      mav.addObject("brands", activeBrands);
      mav.addObject("item", new Item_Entity());
      return mav;
  }
//    @GetMapping("/register_item")
//    public String showRegisterForm(Model model) {
//        model.addAttribute("item", new Item_Entity()); // Add an empty item object
//        model.addAttribute("brands", brandService.getAllBrand()); // Add brands to the model
//        return "Item_Register";
//    }

    
}

