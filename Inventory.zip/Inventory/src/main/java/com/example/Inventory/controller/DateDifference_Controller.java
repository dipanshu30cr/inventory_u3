package com.example.Inventory.controller;

import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.service.DateDifference_Service;
import com.example.Inventory.service.ItemQuantityDifferenceService;
import com.example.Inventory.service.Item_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class DateDifference_Controller 
{
	@Autowired
    private DateDifference_Service dateTimeDifferenceService;

    @Autowired
    private Item_Service itemService;

    @GetMapping("/date_report")
    public String showDateTimeDifferencePage(Model model) {
        List<Item_Entity> items = itemService.getActiveService();
        model.addAttribute("items", items);
        return "DateRangeQuantityDifference";
    }
    
	/*
	 * @GetMapping("/date_purchase_difference") public String
	 * purchaseDateTimeDifferencePage(Model model) { List<Item_Entity> items =
	 * itemService.getAllItem(); model.addAttribute("items", items); return
	 * "Difference_Purchase"; }
	 */
    
    @GetMapping("/purchase_difference")
    public String PurchaseDifferencePage(Model model) {
    	List<Item_Entity> items = itemService.getActiveService();
        model.addAttribute("items", items);
        return "Difference_Purchase"; // assuming Purchase_Difference.html is in your templates directory
    }
    
    @GetMapping("/sales_difference")
    public String SalesDifferencePage(Model model) {
    	List<Item_Entity> items = itemService.getActiveService();
        model.addAttribute("items", items);
        return "Difference_Sales"; // assuming Purchase_Difference.html is in your templates directory
    }

    @PostMapping("/calculateDateTimeDifference")
    public String calculateDateTimeDifferenceAll(
            @RequestParam("itemId") int itemId,
            @RequestParam("startDateTime") LocalDateTime startDateTime,
            @RequestParam("endDateTime") LocalDateTime endDateTime,
            Model model) {

        int difference = dateTimeDifferenceService.calculateDateTimeDifference(itemId, startDateTime, endDateTime);
        //int difference = dateTimeDifferenceService.calculateQuantityDifference(itemId, start, end);
        
        // Fetch the item name
        Item_Entity item = itemService.getItemById(itemId);
        String itemName = item.getItem_name();

        // Add the results to the model
        model.addAttribute("itemId", itemId);
        model.addAttribute("difference", difference);
        model.addAttribute("itemName", itemName);

        // Return the view name (HTML page name)
        return "DateRangeQuantityDifference";
    }
    @PostMapping("/calculate_purchase_difference")
    public String calculatePurchaseQuantity(
            @RequestParam("itemId") int itemId,
            @RequestParam("startDateTime") LocalDateTime startDateTime,
            @RequestParam("endDateTime") LocalDateTime endDateTime,
            Model model) {

        int difference = dateTimeDifferenceService.calculateTotalQuantityPurchasedByItemAndDateRange(itemId, startDateTime, endDateTime);
        
        // Fetch the item name
        Item_Entity item = itemService.getItemById(itemId);
        String itemName = item.getItem_name();

        // Add the results to the model
        model.addAttribute("itemId", itemId);
        model.addAttribute("difference", difference);
        model.addAttribute("itemName", itemName);

        // Return the view name (HTML page name)
        return "Difference_Purchase";
    }
    
    @PostMapping("/calculate_sales_difference")
    public String calculateSalesQuantity(
            @RequestParam("itemId") int itemId,
            @RequestParam("startDateTime") LocalDateTime startDateTime,
            @RequestParam("endDateTime") LocalDateTime endDateTime,
            Model model) {

        int difference = dateTimeDifferenceService.calculateTotalQuantitySalesByItemAndDateRange(itemId, startDateTime, endDateTime);
        
        // Fetch the item name
        Item_Entity item = itemService.getItemById(itemId);
        String itemName = item.getItem_name();

        // Add the results to the model
        model.addAttribute("itemId", itemId);
        model.addAttribute("difference", difference);
        model.addAttribute("itemName", itemName);

        // Return the view name (HTML page name)
        return "Difference_Sales";
    }

	/*
	 * @PostMapping("/calculate_purchase_difference") public String
	 * calculatePurchaseQuantity(
	 * 
	 * @RequestParam("itemId") int itemId,
	 * 
	 * @RequestParam("startDateTime") LocalDateTime startDateTime,
	 * 
	 * @RequestParam("endDateTime") LocalDateTime endDateTime, Model model) {
	 * 
	 * int difference =
	 * dateTimeDifferenceService.calculateTotalQuantityPurchasedByItemAndDateRange(
	 * itemId, startDateTime, endDateTime);
	 * 
	 * // Fetch the item name Item_Entity item = itemService.getItemById(itemId);
	 * String itemName = item.getItem_name();
	 * 
	 * // Add the results to the model model.addAttribute("itemId", itemId);
	 * model.addAttribute("difference", difference); model.addAttribute("itemName",
	 * itemName);
	 * 
	 * // Return the view name (HTML page name) return "Difference_Purchase"; }
	 */

	/*
	 * @GetMapping("/purchase_difference") public String
	 * calculateDateTimeDifferencePurchase(
	 * 
	 * @RequestParam("itemId") int itemId,
	 * 
	 * @RequestParam("startDateTime") LocalDateTime startDateTime,
	 * 
	 * @RequestParam("endDateTime") LocalDateTime endDateTime, Model model) {
	 * 
	 * int difference =
	 * dateTimeDifferenceService.calculateTotalQuantityPurchasedByItemAndDateRange(
	 * itemId, startDateTime, endDateTime); //int difference =
	 * dateTimeDifferenceService.calculateQuantityDifference(itemId, start, end);
	 * 
	 * // Fetch the item name Item_Entity item = itemService.getItemById(itemId);
	 * String itemName = item.getItem_name();
	 * 
	 * // Add the results to the model model.addAttribute("itemId", itemId);
	 * model.addAttribute("difference", difference); model.addAttribute("itemName",
	 * itemName);
	 * 
	 * // Return the view name (HTML page name) return
	 * "DateRangeQuantityDifference"; }
	 */
//    @PostMapping("/calculateDateRangeQuantityDifference")
//    public String calculateDateRangeQuantityDifference(
//            @RequestParam("itemId") int itemId,
//            @RequestParam("startDate") String startDate,
//            @RequestParam("endDate") String endDate,
//            Model model) {
//        
//    	LocalDateTime start = LocalDateTime.parse(startDate);
//    	LocalDateTime end = LocalDateTime.parse(endDate);
//
//        int difference = dateRangeQuantityDifferenceService.calculateQuantityDifference(itemId, start, end);
//        
//        // Fetch the item name
//        Item_Entity item = itemService.getItemById(itemId);
//        String itemName = item.getItem_name();
//
//        // Add the results to the model
//        model.addAttribute("itemId", itemId);
//        model.addAttribute("difference", difference);
//        model.addAttribute("itemName", itemName);
//
//        return "DateRangeQuantityDifference";
//    }
}
