package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class SalesM_Entity 
{
	
	@Id                                                 //shows the first data is id
	@GeneratedValue(strategy= GenerationType.IDENTITY) //used for auto_increment
	int salesMid;
	String Customer_name;
	String phn;
	String invoice_no ;
	@Column(name = "date_time")                         // Mapping to the database column
    private LocalDateTime invoice_date;
	int total;
	boolean status;
	
	@OneToMany(mappedBy = "salesMaster_id", cascade= CascadeType.ALL)
    private List<SalesD_Entity> SalesD;
	
	
	public SalesM_Entity(int salesMid, String customer_name, String phn, String invoice_no,
			LocalDateTime invoice_date, int total, boolean status) {
		super();
		this.salesMid = salesMid;
		Customer_name = customer_name;
		this.phn = phn;
		this.invoice_no = invoice_no;
		this.invoice_date = invoice_date;
		this.total = total;
		this.status = status;
	}
	public SalesM_Entity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSalesMid() {
		return salesMid;
	}
	public void setSalesMid(int salesMid) {
		this.salesMid = salesMid;
	}
	public String getCustomer_name() {
		return Customer_name;
	}
	public void setCustomer_name(String customer_name) {
		Customer_name = customer_name;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public String getInvoice_no() {
		return invoice_no;
	}
	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}
	public LocalDateTime getInvoice_date() {
		return invoice_date;
	}
	public void setInvoice_date(LocalDateTime invoice_date) {
		this.invoice_date = invoice_date;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "SalesM_Entity [salesMid=" + salesMid + ", Customer_name=" + Customer_name + ", phn=" + phn
				+ ", invoice_no=" + invoice_no + ", invoice_date=" + invoice_date + ", total=" + total + ", status="
				+ status + "]";
	}
	
	
	
}
