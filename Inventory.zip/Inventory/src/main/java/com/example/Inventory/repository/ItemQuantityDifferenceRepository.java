//package com.example.Inventory.repository;
//
//public interface ItemQuantityDifferenceRepository {
//
//}

package com.example.Inventory.repository;

import com.example.Inventory.entity.ItemQuantityDifference_Entity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemQuantityDifferenceRepository extends JpaRepository<ItemQuantityDifference_Entity, Integer> {
    // Add custom query methods if needed
	
	 
}

