
package com.example.Inventory.controller;

import java.util.Collections;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.editor.SupplierMEntityEditor;
import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseD_Entity;
import com.example.Inventory.entity.PurchaseM_Entity;
import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.repository.Item_Repository;
import com.example.Inventory.service.Item_Service;
import com.example.Inventory.service.PurchaseD_Service;
import com.example.Inventory.service.PurchaseM_Service;
import com.example.Inventory.service.Supplier_Service;

@Controller
public class PurchaseD_Controller {

    @Autowired 
    private PurchaseD_Service pde;
    
    @Autowired 
    private Item_Service ite;
    
    @Autowired 
    private PurchaseM_Service pme;
    
    @Autowired
    private Item_Repository itemRepository;
    
    @Autowired
    private Supplier_Service ss;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(SupplierM_Entity.class, new SupplierMEntityEditor(ss));
    }

    @GetMapping("/purchase_details")
    public ModelAndView AllPurchaseDetails() {
        List<PurchaseD_Entity> list = pde.getallpurchasedetails();
        
        // Log the fetched data for debugging
        /*for (PurchaseD_Entity detail : list) {
            System.out.println("Purchase Detail ID: " + detail.getPd_id());
            System.out.println("Item ID: " + (detail.getPDitem_id() != null ? detail.getPDitem_id().getItem_id() : "null"));
            System.out.println("Item Name: " + (detail.getPDitem_id() != null ? detail.getPDitem_id().getItem_name() : "null"));*/
        //}
        return new ModelAndView("PurchaseD", "purchased", list);
    }

    @GetMapping("/delete_purchaseDetails/{id}")
    public String deletePurchaseDetails(@PathVariable("id") int id) {
        pde.deleteByid(id);
        return "redirect:/purchase_details";
    }

    @RequestMapping("/edit_purchasedetail{id}")
    public String editpurchaseD(@PathVariable("id") int id, Model model) {
        PurchaseD_Entity l3 = pde.getbyid(id);
        List<PurchaseM_Entity> purchaseMasters = pme.getallpurchaseM();
        List<Item_Entity> purchaseItems = ite.getAllItem();
        model.addAttribute("purchased", l3);
        model.addAttribute("purchaseitem", ite.getActiveService());
        model.addAttribute("suppliers", ss.getActiveSupplierMaster());
        model.addAttribute("purchasemaster", purchaseMasters);
        model.addAttribute("purchaseitem", purchaseItems);
        return "PurchaseD_Edit";
    }

    @GetMapping("/purchased_register")
    public String showPurchaseRegisterForm(Model model) {
        model.addAttribute("purchasem", new PurchaseM_Entity());
        model.addAttribute("purchased", new PurchaseD_Entity());
        model.addAttribute("purchaseitem", ite.getActiveService());
        model.addAttribute("purchase_supplier", ss.getActiveSupplierMaster());
        return "PurchaseD_Register";
    }

    
    @PostMapping("/save_purchase")
    public String savePurchase(@ModelAttribute("purchasem") PurchaseM_Entity purchaseM,
                               @ModelAttribute("purchased") PurchaseD_Entity purchaseD ) {
        // Save the Purchase Master entity first
        pme.save(purchaseM);

        // Fetch the associated Item_Entity by its ID
        Item_Entity item = itemRepository.findById(purchaseD.getPDitem_id().getItem_id()).orElse(null);
        if (item != null) {
            // Set the fetched Item_Entity to the PurchaseD_Entity
            purchaseD.setPDitem_id(item);
        }

        // Set the Purchase Master entity to PurchaseD_Entity
        purchaseD.setPurchaseMaster_id(purchaseM);
        
        // Save the PurchaseD_Entity
        pde.save(purchaseD);
        
        return "redirect:/purchase_details";
    }

    @PostMapping("/save_purchased")
    @ResponseBody
    public ResponseEntity<?> savePurchase(@RequestBody List<PurchaseD_Entity> purchaseDetails) {
        try {
            // Save each purchase detail to the database
            for (PurchaseD_Entity detail : purchaseDetails) {
                pde.save(detail);  // Adjust this to your actual save method
            }
            
            return ResponseEntity.ok().body(Collections.singletonMap("success", true));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("success", false));
        }
    }

    @PostMapping("/edit_save_purchase")
    public String savePurchaseDetails(@ModelAttribute("purchased") PurchaseD_Entity purchaseDetails) {
        pde.save(purchaseDetails);
        return "redirect:/purchase_details";
    }
}
