//package com.example.Inventory.service;
//
//
//import java.util.*;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//
//import com.example.Inventory.entity.Brand_Entity;
//import com.example.Inventory.repository.Brand_Repository;
//
//@Service
//public class Brand_Service 
//{
//	@Autowired Brand_Repository brepo;
//	
//	public void save(Brand_Entity b)
//	{
//		brepo.save(b);
//	}
//	
//	public List<Brand_Entity> getAllBrand()
//	{
//		return brepo.findAll();
//	}
//	
//	public Brand_Entity getBrandById(int id)
//	{
//		return brepo.findById(id).get ();
//	}
//	public void deleteByid(int id)
//	{
//		brepo.deleteById(id);
//	}
//	public boolean existsByName(String name) {
//	    return brepo.existsByName(name);
//	}
//	
//	public List<Brand_Entity> getActiveBrands() {
//        return brepo.findByStatusTrue();
//    }
//
//}
package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.repository.Brand_Repository;

@Service
public class Brand_Service {
    @Autowired 
    private Brand_Repository brepo;

    public void save(Brand_Entity b) {
        brepo.save(b);
    }

    public List<Brand_Entity> getAllBrand() {
        return brepo.findAll();
    }

    public Brand_Entity getBrandById(int id) {
        return brepo.findById(id).orElse(null);
    }

    public void deleteByid(int id) {
        brepo.deleteById(id);
    }

    public boolean existsByName(String name) {
        return brepo.existsByName(name);
    }

    public List<Brand_Entity> getActiveBrands() {
        return brepo.findByStatusTrue();
    }

    public void softDeleteById(int id) {
        Brand_Entity brand = getBrandById(id);
        if (brand != null) {
            brand.setStatus(false);
            save(brand);
        }
    }
    @Autowired
    private Brand_Repository brandRepository;

    public boolean brandNameExists(String name) {
        return brandRepository.existsByName(name);
    }
}

