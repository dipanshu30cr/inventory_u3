package com.example.Inventory.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.Brand_Entity;

@Repository
public interface Brand_Repository extends JpaRepository< Brand_Entity , Integer> 
{
	boolean existsByName(String name);
	
	List<Brand_Entity> findByStatusTrue();
}
