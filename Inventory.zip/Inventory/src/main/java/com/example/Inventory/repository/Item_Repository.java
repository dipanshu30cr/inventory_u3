package com.example.Inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.Item_Entity;

import jakarta.transaction.Transactional;

public interface Item_Repository extends JpaRepository< Item_Entity , Integer>  
{
	List<Item_Entity> findByStatusTrue();
	
	//boolean existsByitem_name(String name);
	//boolean checkItemName(String item_name, int brandId);
	//boolean existsByItemNameAndBrandId(String item_name, int brand_id);
	@Query("SELECT CASE WHEN COUNT(i) > 0 THEN TRUE ELSE FALSE END FROM Item_Entity i WHERE i.item_name = :itemName AND i.brand_id.id = :brandId")
    boolean existsByItemNameAndBrandId(@Param("itemName") String itemName, @Param("brandId") int brandId);
	
	
	 @Modifying
	    @Transactional
	    @Query("UPDATE Item_Entity i SET i.status = false WHERE i.item_id = :itemId")
	    void softDeleteById(@Param("itemId") int itemId);
	
}
