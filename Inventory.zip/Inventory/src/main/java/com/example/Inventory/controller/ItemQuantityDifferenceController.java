//package com.example.Inventory.controller;
//
//public class ItemQuantityDifferenceController {
//
//}

package com.example.Inventory.controller;

import com.example.Inventory.entity.ItemQuantityDifference_Entity;
import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseD_Entity;
import com.example.Inventory.repository.PurchaseD_Repository;
import com.example.Inventory.repository.SalesD_Repository;
import com.example.Inventory.service.ItemQuantityDifferenceService;
import com.example.Inventory.service.Item_Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ItemQuantityDifferenceController {

    private final PurchaseD_Repository purchaseDRepository;
    private final SalesD_Repository salesDRepository;
    
    @Autowired ItemQuantityDifferenceService pde;
    @Autowired Item_Service ite;

    @Autowired
    public ItemQuantityDifferenceController(PurchaseD_Repository purchaseDRepository, SalesD_Repository salesDRepository) {
        this.purchaseDRepository = purchaseDRepository;
        this.salesDRepository = salesDRepository;
    }
    
    @GetMapping("/stock_report")
    public String showStockReport(Model model) {
    	model.addAttribute("itemId", new ItemQuantityDifference_Entity());
    	model.addAttribute("itemdifference", ite.getActiveService()); 
        return "ItemQuantityDifference"; // Return the name of the HTML page
    }

    @PostMapping("/calculateItemQuantityDifference")
    public String calculateItemQuantityDifference(@RequestParam("iqd") int itemId, Model model) {
        Integer purchaseQuantity = purchaseDRepository.sumQuantityByItemId(itemId);
        Integer salesQuantity = salesDRepository.sumQuantityByItemId(itemId);

        // Handling null values if no records found for the item ID
        int difference = (purchaseQuantity != null ? purchaseQuantity : 0) - (salesQuantity != null ? salesQuantity : 0);

        // Add the results to the model
//        model.addAttribute("itemId", itemId);
//        model.addAttribute("difference", difference);
        Item_Entity item = ite.getItemById(itemId);
        String itemName = item.getItem_name();

        // Add the results to the model
        model.addAttribute("itemId", itemId);
        model.addAttribute("difference", difference);
        model.addAttribute("itemName", itemName);
        // Return the view name (HTML page name)
        return "ItemQuantityDifference";
    }
}

