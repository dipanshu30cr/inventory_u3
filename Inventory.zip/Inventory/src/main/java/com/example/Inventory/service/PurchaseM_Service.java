package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseM_Entity;
import com.example.Inventory.entity.SalesD_Entity;
import com.example.Inventory.repository.PurchaseM_Repository;

@Service
public class PurchaseM_Service 
{
	
	@Autowired PurchaseM_Repository prepo;
	
	public void save(PurchaseM_Entity pme)
	{
		prepo.save(pme);
	}
	
	public List<PurchaseM_Entity> getallpurchaseM()
	{
		return prepo.findAll();
	}
	
	
	public PurchaseM_Entity getbyid(int id)
	{
		return prepo.findById(id).get();
	}
	
	public void deleteByid(int id)
	{
		prepo.deleteById(id);
	}
	
	public List<PurchaseM_Entity> getActiveService() {
        return prepo.findByStatusTrue();
    }
	

}
