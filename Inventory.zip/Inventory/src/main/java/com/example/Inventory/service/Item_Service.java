package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.repository.Item_Repository;
import com.example.Inventory.repository.PurchaseD_Repository;

@Service
public class Item_Service 
{
	@Autowired
	Item_Repository irepo;
	
	@Autowired PurchaseD_Repository purchaseDRepository;
	public void save(Item_Entity b)
	{
		irepo.save(b);
	}
	
	public List<Item_Entity> getAllItem()
	{
		return irepo.findAll();
	}
	
	
	
	public Item_Entity getItemById(int id)
	{
		return irepo.findById(id).get ();
	}
	public void deleteByid(int id)
	{
		irepo.deleteById(id);
	}
	
	 public void saveItem(Item_Entity item) {
	        irepo.save(item);
	    }
	 
	 public List<Item_Entity> getActiveService() {
	        return irepo.findByStatusTrue();
	    }
	 
//	 public boolean existsByItemNameAndBrandId(String itemName, int brandId) {
//	        return irepo.existsByItemNameAndBrand_Id(itemName, brandId);
//	    }
	 
//	 public boolean existsByitem_name(String name) {
//		    return existsByitem_name(name);
//		}
	 public boolean existsByItemNameAndBrandId(String itemName, int brandId) {
	        return irepo.existsByItemNameAndBrandId(itemName, brandId);
	    }
	 
	 public int getPurchaseQuantity(Item_Entity item) {
	        // Use PurchaseD_Repository method to retrieve purchase quantity by item
	        Integer purchaseQuantity = purchaseDRepository.sumQuantityByItemId(item.getItem_id());
	        return purchaseQuantity != null ? purchaseQuantity : 0;
	    }
	 
	 
}
