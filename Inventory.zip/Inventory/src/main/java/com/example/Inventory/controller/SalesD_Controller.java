package com.example.Inventory.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


import com.example.Inventory.entity.Item_Entity;
import com.example.Inventory.entity.PurchaseD_Entity;
import com.example.Inventory.entity.PurchaseM_Entity;
import com.example.Inventory.entity.SalesD_Entity;
import com.example.Inventory.entity.SalesM_Entity;
import com.example.Inventory.service.Item_Service;
import com.example.Inventory.service.SalesD_Service;
import com.example.Inventory.service.SalesM_Service;

@Controller
public class SalesD_Controller {

    @Autowired
    SalesD_Service sds;

    @Autowired
    SalesM_Service sms;

    @Autowired
    Item_Service is;

    @GetMapping("/sale_details")
    public ModelAndView allSalesDetails() {
        List<SalesD_Entity> list = sds.getallsellsdetails();
        return new ModelAndView("SalesD", "salesd", list);
    }
    
    @GetMapping("/previous_sales_quantity/{itemId}")
    public int getPreviousSalesQuantity(@PathVariable int itemId) {
        return sds.getPreviousSalesQuantity(itemId);
    }

    @RequestMapping("/salesd_register")
    public String showSalesDetailsForm(Model model) {
        model.addAttribute("salesd", new SalesD_Entity());
        model.addAttribute("purchasem", new PurchaseM_Entity());
        model.addAttribute("salesitem", is.getActiveService());
        model.addAttribute("salesmaster", sms.getActiveSalesMaster());
        model.addAttribute("sales_customer", sms.getActiveSalesMaster());
        return "SalesD_Register";
    }
    
    
    
    
    
    


    @PostMapping("/save_salesd")
    public String saveSalesDetails(@ModelAttribute("salesd") SalesD_Entity salesDetails) {
        // Check if the quantity being sold exceeds the available quantity in the purchase table
        int itemId = salesDetails.getSDitem_id().getItem_id(); // Get the item ID from sales details
        int salesQuantity = salesDetails.getQty();
        int purchaseQuantity = is.getPurchaseQuantity(salesDetails.getSDitem_id()); // Get purchase quantity from item service
        
        if (salesQuantity > purchaseQuantity) {
            // If quantity being sold exceeds purchase quantity, return to form with error message
            return "redirect:/salesd_register?error=Quantity exceeds available quantity";
        }

        // Otherwise, proceed with saving the sales details
        sds.save(salesDetails);
        return "redirect:/sale_details";
    }
    
    
    @PostMapping("/salesd_save_register")
    public String savePurchase(@ModelAttribute("sales") SalesM_Entity salesM,
                               @ModelAttribute("salesd") SalesD_Entity salesD, Model  model,
                               @RequestParam("Customer_name") String customerName
                               ) {
    	
    	model.addAttribute("salesd", new SalesD_Entity());
        model.addAttribute("purchasem", new PurchaseM_Entity());
        model.addAttribute("salesitem", is.getActiveService());
        model.addAttribute("salesmaster", sms.getActiveSalesMaster());
        model.addAttribute("sales_customer", sms.getActiveSalesMaster());
        model.addAttribute("customerName", customerName);
        
        
        sms.save(salesM);
        salesD.setSalesMaster_id(salesM);
        sds.save(salesD);
        //return "redirect:/sales_details";
        int itemId = salesD.getSDitem_id().getItem_id(); // Get the item ID from sales details
        int salesQuantity = salesD.getQty();
        int purchaseQuantity = is.getPurchaseQuantity(salesD.getSDitem_id()); // Get purchase quantity from item service
        
        if (salesQuantity > purchaseQuantity) {
            // If quantity being sold exceeds purchase quantity, return to form with error message
            return "redirect:/salesd_register?error=Quantity exceeds available quantity";
        }

        // Otherwise, proceed with saving the sales details
        sds.save(salesD);
        return "redirect:/sale_details";
    }
     
    
    

	/*
	 * @GetMapping("/delete_salesDetail/{id}") public String
	 * deleteSalesDetails(@PathVariable("id") int id) { sds.deleteByid(id); return
	 * "redirect:/sale_details"; }
	 */
    @GetMapping("/delete_salesDetail/{id}")
    public String deleteSalesDetails(@PathVariable("id") int id) {
        SalesD_Entity salesDetail = sds.getbyid(id);
        if (salesDetail != null) {
            salesDetail.setStatus(false); // Soft-delete by setting status to false
            sds.save(salesDetail); // Save the updated entity
        }
        return "redirect:/sale_details";
    }
    
    

    @RequestMapping("/edit_salesdetail{id}")
    public String editSalesD(@PathVariable("id") int id, Model model) {
    	
    	
        SalesD_Entity l3 = sds.getbyid(id);
        model.addAttribute("salesd", l3); // Ensure 'salesd' is the correct attribute name
        // Add additional attributes for dropdowns if needed
        model.addAttribute("salesitem", is.getAllItem());
        model.addAttribute("salesmaster", sms.getAllSalesM());
        return "SalesD_Edit";
    }

    @GetMapping("/purchase/quantity/{itemId}")
    @ResponseBody
    public int getPurchaseQuantity(@PathVariable("itemId") int itemId) {
        // Retrieve the purchase quantity of the selected item from the service
        Item_Entity item = is.getItemById(itemId);
        return is.getPurchaseQuantity(item);
    }
    
    @PostMapping("/update_salesd")
    public String updateSalesDetails(@ModelAttribute("salesd") SalesD_Entity salesDetails) {
        // Check if the quantity being sold exceeds the available quantity in the purchase table
        int itemId = salesDetails.getSDitem_id().getItem_id(); // Get the item ID from sales details
        int salesQuantity = salesDetails.getQty();
        int purchaseQuantity = is.getPurchaseQuantity(salesDetails.getSDitem_id()); // Get purchase quantity from item service
        
        if (salesQuantity > purchaseQuantity) {
            // If quantity being sold exceeds purchase quantity, return to form with error message
            return "redirect:/sale_details?error=Quantity exceeds available quantity";
            
        }

        // Otherwise, proceed with saving the sales details
        sds.save(salesDetails);
        return "redirect:/sale_details";
    }

}