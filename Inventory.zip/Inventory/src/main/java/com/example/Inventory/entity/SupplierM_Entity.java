package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="supplier_master")
public class SupplierM_Entity 
{
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int supplier_id;
	private String name;
	
	@Column(unique = true)
	private String mob;
	private String address;
	@Column(name = "date_time") // Mapping to the database column
    private LocalDateTime datetime;
	boolean status;
	
	@OneToMany(mappedBy = "PM_Supplier_id", cascade= CascadeType.ALL)
    private List<PurchaseM_Entity> PM_Supplier_id;
    
    @OneToMany(mappedBy = "SupplierPurchase", cascade= CascadeType.ALL)
    private List<Master_Purchase> SupplierPurchase;
//    @OneToMany(mappedBy = "PurchaseSupplier", cascade= CascadeType.ALL)
//    private List<PurchaseD_Entity> PurchaseSupplier;
//    @OneToMany(mappedBy = "SDitem_id", cascade= CascadeType.ALL)
//    private List<SalesD_Entity> SalesDitem;
	
	public SupplierM_Entity(int supplier_id, String name, String mob, String address, LocalDateTime datetime,
			boolean status) {
		super();
		this.supplier_id = supplier_id;
		this.name = name;
		this.mob = mob;
		this.address = address;
		this.datetime = datetime;
		this.status = status;
	}
	public SupplierM_Entity() {
		super();
	
	}
	public int getSupplier_id() {
		return supplier_id;
	}
	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "SupplierM_Entity [supplier_id=" + supplier_id + ", name=" + name + ", mob=" + mob + ", address="
				+ address + ", datetime=" + datetime + ", status=" + status + "]";
	}
	
	

}
