package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.SalesM_Entity;
import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.repository.Supplier_Repository;

@Service
public class Supplier_Service 
{
	@Autowired
	Supplier_Repository  srepo;
	
	public void save(SupplierM_Entity b)
	{
		srepo.save(b);
	}
	
	public List<SupplierM_Entity> getAllSupplier()
	{
		return srepo.findAll();
	}
	
	public SupplierM_Entity getSupplierById(int id)
	{
		return srepo.findById(id).get ();
	}
	public void deleteByid(int id)
	{
		srepo.deleteById(id);
	}
	
	public List<SupplierM_Entity> getActiveSupplierMaster() {
        return srepo.findByStatus_True();
    }
	
	public boolean existsByMob(String mob) {
	    return srepo.existsByMob(mob);
	}
	

    public void softDeleteSupplier(int id) {
        SupplierM_Entity supplier = srepo.findById(id).orElse(null);
        if (supplier != null) {
            supplier.setStatus(false); // Set status to false (inactive)
            srepo.save(supplier); // Update the supplier in the database
        }
    }
	


	
}
