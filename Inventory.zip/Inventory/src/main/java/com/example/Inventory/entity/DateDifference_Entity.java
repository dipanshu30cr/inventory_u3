package com.example.Inventory.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Date_Difference")
public class DateDifference_Entity 
{
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    // Direct foreign key reference to Item_Entity
	    @ManyToOne
	    @JoinColumn(name = "dd")
	    private Item_Entity dd;

	    @Column(name = "purchase_date")
	    private LocalDateTime purchase_date;
	    
	    @Column(name = "sales_date")
	    private LocalDateTime sales_date;
	    
	    @Column(name = "quantity_difference")
	    private int date_quantityDifference;

		public DateDifference_Entity(int id, Item_Entity dd, LocalDateTime purchase_date, LocalDateTime sales_date,
				int date_quantityDifference) {
			super();
			this.id = id;
			this.dd = dd;
			this.purchase_date = purchase_date;
			this.sales_date = sales_date;
			this.date_quantityDifference = date_quantityDifference;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Item_Entity getDd() {
			return dd;
		}

		public void setDd(Item_Entity dd) {
			this.dd = dd;
		}

		public LocalDateTime getPurchase_date() {
			return purchase_date;
		}

		public void setPurchase_date(LocalDateTime purchase_date) {
			this.purchase_date = purchase_date;
		}

		public LocalDateTime getSales_date() {
			return sales_date;
		}

		public void setSales_date(LocalDateTime sales_date) {
			this.sales_date = sales_date;
		}

		public int getDate_quantityDifference() {
			return date_quantityDifference;
		}

		public void setDate_quantityDifference(int date_quantityDifference) {
			this.date_quantityDifference = date_quantityDifference;
		}

		public DateDifference_Entity() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "DateDifference_Entity [id=" + id + ", dd=" + dd + ", purchase_date=" + purchase_date
					+ ", sales_date=" + sales_date + ", date_quantityDifference=" + date_quantityDifference + "]";
		}

		
	    
	    
	    
	    
	    
	    
}
