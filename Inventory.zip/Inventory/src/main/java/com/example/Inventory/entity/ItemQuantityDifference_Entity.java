package com.example.Inventory.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Item_Quantity_Difference")
public class ItemQuantityDifference_Entity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    // Direct foreign key reference to Item_Entity
    @ManyToOne
    @JoinColumn(name = "iqd")
    private Item_Entity iqd;

    @Column(name = "quantity_difference")
    private int quantityDifference;

    // Constructors, getters, and setters
    public ItemQuantityDifference_Entity() {
    }

    public ItemQuantityDifference_Entity(Item_Entity iqd, int quantityDifference) {
        this.iqd = iqd;
        this.quantityDifference = quantityDifference;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Item_Entity getItem() {
        return iqd;
    }

    public void setItem(Item_Entity item) {
        this.iqd = item;
    }

    public int getQuantityDifference() {
        return quantityDifference;
    }

    public void setQuantityDifference(int quantityDifference) {
        this.quantityDifference = quantityDifference;
    }
}
