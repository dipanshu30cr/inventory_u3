package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Product_Dtails")
public class PurchaseD_Entity 

{
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	int pd_id;
	int qty;
	int price;
	double amount;
	@Column(name = "date_time") // Mapping to the database column
    private LocalDateTime purchaseD_datetime;
	boolean status= true;
	
	@ManyToOne
	@JoinColumn(name = "PDitem_id")
    private Item_Entity PDitem_id;
	
	@ManyToOne
	@JoinColumn(name = "PurchaseMaster_id", nullable = true)
    private PurchaseM_Entity PurchaseMaster_id;
	


	public PurchaseD_Entity(int pd_id, int qty, int price, int amount, LocalDateTime purchaseD_datetime, boolean status,
			Item_Entity pDitem_id, PurchaseM_Entity purchaseMaster_id) {
		super();
		this.pd_id = pd_id;
		this.qty = qty;
		this.price = price;
		this.amount = amount;
		this.purchaseD_datetime = purchaseD_datetime;
		this.status = status;
		PDitem_id = pDitem_id;
		PurchaseMaster_id = purchaseMaster_id;
	}
	
	

	public int getPd_id() {
		return pd_id;
	}

	public void setPd_id(int pd_id) {
		this.pd_id = pd_id;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDateTime getPurchaseD_datetime() {
		return purchaseD_datetime;
	}

	public void setPurchaseD_datetime(LocalDateTime purchaseD_datetime) {
		this.purchaseD_datetime = purchaseD_datetime;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Item_Entity getPDitem_id() {
		return PDitem_id;
	}

	public void setPDitem_id(Item_Entity pDitem_id) {
		PDitem_id = pDitem_id;
	}

	public PurchaseM_Entity getPurchaseMaster_id() {
		return PurchaseMaster_id;
	}

	public void setPurchaseMaster_id(PurchaseM_Entity purchaseMaster_id) {
		PurchaseMaster_id = purchaseMaster_id;
	}

	public PurchaseD_Entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PurchaseD_Entity [pd_id=" + pd_id + ", qty=" + qty + ", price=" + price + ", amount=" + amount
				+ ", purchaseD_datetime=" + purchaseD_datetime + ", status=" + status + ", PDitem_id=" + PDitem_id
				+ ", PurchaseMaster_id=" + PurchaseMaster_id + "]";
	}

	
	}