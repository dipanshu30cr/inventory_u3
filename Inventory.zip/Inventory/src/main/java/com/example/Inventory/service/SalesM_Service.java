package com.example.Inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.SalesM_Entity;

import com.example.Inventory.repository.SalesM_Repository;



@Service
public class SalesM_Service 
{
	@Autowired SalesM_Repository sarepo;
	
	
	public void save(SalesM_Entity b)                   //for save, we take entity as parameter
	{
		sarepo.save(b);
	}
	
	public List<SalesM_Entity> getAllSalesM()         //we used list
	{
		return sarepo.findAll();
	}
	
	public SalesM_Entity getSalesMById(int id)
	{
		return sarepo.findById(id).get ();
	}
	public void deleteByid(int id)
	{
		sarepo.deleteById(id);
	}
	public List<SalesM_Entity> getActiveSalesMaster() {
        return sarepo.findByStatusTrue();
    }
	
	public boolean existsByPhn(String phn) {
	    return sarepo.existsByPhn(phn);
	}
	public boolean phoneExistsWithDifferentId(String phone, int currentId) {
	    List<SalesM_Entity> sales = sarepo.findByPhn(phone);
	    return sales.stream().anyMatch(sale -> sale.getSalesMid() != currentId);
	}

	
}
