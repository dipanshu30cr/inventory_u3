package com.example.Inventory.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.SalesD_Entity;

@Repository
public interface SalesD_Repository extends JpaRepository<SalesD_Entity, Integer>{
	
	@Query("SELECT SUM(s.qty) FROM SalesD_Entity s WHERE s.SDitem_id.item_id = :itemId")
    Integer sumQuantityByItemId(int itemId);
	
	
	
	@Query("SELECT SUM(s.qty) FROM SalesD_Entity s WHERE s.SDitem_id.item_id = :itemId AND s.saleD_datetime BETWEEN :startDateTime AND :endDateTime")
    Integer sumQuantityByItemIdAndDateTimeRange(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime);
	
	 @Query("SELECT s FROM SalesD_Entity s WHERE s.SDitem_id.item_id = :itemId")
	    SalesD_Entity findByItemId(@Param("itemId") int itemId);
	 
	 


}
