package com.example.Inventory.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Inventory.entity.DateDifference_Entity;
import com.example.Inventory.repository.PurchaseD_Repository;
import com.example.Inventory.repository.SalesD_Repository;

@Service
public class DateDifference_Service {


    @Autowired
    private PurchaseD_Repository purchaseDRepository;

    @Autowired
    private SalesD_Repository salesDRepository;

    public int calculateDateTimeDifference(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        // Get the purchased quantity within the date range
        Integer purchasedQuantity = purchaseDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);
        // Get the sold quantity within the date range
        Integer soldQuantity = salesDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);

        // Handle null values
        purchasedQuantity = purchasedQuantity != null ? purchasedQuantity : 0;
        soldQuantity = soldQuantity != null ? soldQuantity : 0;

        // Calculate the difference
        return purchasedQuantity - soldQuantity;
    }
    public int calculateTotalQuantityPurchasedByItemAndDateRange(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        // Get the purchased quantity within the date range
        Integer purchasedQuantity = purchaseDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);
        // Get the sold quantity within the date range
       // Integer soldQuantity = salesDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);

        // Handle null values
        int totalQuantity = purchasedQuantity != null ? purchasedQuantity : 0;
       // purchasedQuantity = purchasedQuantity != null ? purchasedQuantity : 0;
        
       // totalQuantity= purchasedQuantity;
        // Calculate the difference
        return totalQuantity;
    }
    public int calculateTotalQuantitySalesByItemAndDateRange(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        // Get the purchased quantity within the date range
       // Integer purchasedQuantity = purchaseDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);
        // Get the sold quantity within the date range
        Integer soldQuantity = salesDRepository.sumQuantityByItemIdAndDateTimeRange(itemId, startDateTime, endDateTime);

        // Handle null values
        int totalQuantity = soldQuantity != null ? soldQuantity : 0;
       // purchasedQuantity = purchasedQuantity != null ? purchasedQuantity : 0;
        
       // totalQuantity= purchasedQuantity;
        // Calculate the difference
        return totalQuantity;
    }
    
    
}

