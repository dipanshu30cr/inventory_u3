package com.example.Inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.Inventory.editor.SupplierMEntityEditor;
import com.example.Inventory.entity.PurchaseM_Entity;
import com.example.Inventory.entity.SalesD_Entity;
import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.service.PurchaseM_Service;
import com.example.Inventory.service.Supplier_Service;

@Controller
public class PurchaseM_Controller {

    @Autowired
    private PurchaseM_Service pms;

    @Autowired
    private Supplier_Service ss;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(SupplierM_Entity.class, new SupplierMEntityEditor(ss));
    }

    @GetMapping("/purchase_mstr")
    public ModelAndView AllSalesDetails() {
        List<PurchaseM_Entity> list = pms.getallpurchaseM();
        return new ModelAndView("PurchaseM", "purchasem", list);
    }
    
    

    @GetMapping("/purchasem_register")
    public String showPurchaseMRegisterForm(Model model) {
        model.addAttribute("purchasem", new PurchaseM_Entity());
        List<SupplierM_Entity> suppliers = ss.getActiveSupplierMaster();
        model.addAttribute("purchase_supplier", suppliers);
        return "PurchaseM_Register";
    }

    @PostMapping("/save_purchasem")
    public String savePurchaseM(@ModelAttribute("purchasem") PurchaseM_Entity purchaseM) {
        pms.save(purchaseM);
        return "redirect:/purchase_mstr";
        
    }
    
    @GetMapping("/delete_purchaseM/{id}")
    public String deletePurchaseMaster(@PathVariable("id") int id) {
        pms.deleteByid(id);
        return "redirect:/purchase_mstr"; // Redirect to the supplier management page
    }
    @RequestMapping("/edit_purchaseM{id}")
    public String editPurchaseM(@PathVariable("id") int id, Model model) {    
        PurchaseM_Entity purchasem = pms.getbyid(id);
        model.addAttribute("purchasem", purchasem); // Correct attribute name to match the form
        List<SupplierM_Entity> suppliers = ss.getAllSupplier();
        model.addAttribute("purchase_supplier", suppliers); // Correctly name this attribute for dropdown
        
        return "PurchaseM_Edit";
    }
   
}
