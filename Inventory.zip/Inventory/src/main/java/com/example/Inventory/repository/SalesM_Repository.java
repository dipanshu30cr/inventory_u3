package com.example.Inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.Brand_Entity;
import com.example.Inventory.entity.SalesM_Entity;


@Repository
public interface SalesM_Repository  extends JpaRepository< SalesM_Entity , Integer> {
	

	

	boolean existsByPhn(String phn);
	
	List<SalesM_Entity> findByStatusTrue();
	List<SalesM_Entity> findByPhn(String phone);


}
