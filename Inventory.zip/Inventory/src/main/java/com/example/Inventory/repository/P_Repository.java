

package com.example.Inventory.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Inventory.entity.Master_Purchase;
import com.example.Inventory.entity.PurchaseD_Entity;

@Repository
public interface P_Repository extends JpaRepository<Master_Purchase, Integer>{
//	@Query("SELECT SUM(p.qty) FROM Master_purchase p WHERE p.PDitem_id.item_id = :itemId")
//    Integer sumQuantityByItemId(int itemId);
	
	
	
//	@Query("SELECT SUM(p.qty) FROM Master_purchase p WHERE p.PDitem_id.item_id = :itemId AND p.purchaseD_datetime BETWEEN :startDateTime AND :endDateTime")
//    Integer sumQuantityByItemIdAndDateTimeRange(int itemId, LocalDateTime startDateTime, LocalDateTime endDateTime);

}
