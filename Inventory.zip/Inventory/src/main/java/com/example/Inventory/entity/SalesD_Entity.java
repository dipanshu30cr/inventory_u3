package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Sales_Details")
public class SalesD_Entity 
{
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	int salesD_id;
	int qty;
	int salesD_price;
	double salesD_amount;
	@Column(name = "date_time") // Mapping to the database column
    private LocalDateTime saleD_datetime;
	boolean status;
	@ManyToOne
	@JoinColumn(name = "SDitem_id", nullable = false)
    private Item_Entity SDitem_id;
	
	@ManyToOne
	@JoinColumn(name = "salesMaster_id", nullable = false)
    private SalesM_Entity salesMaster_id;
	


	public SalesD_Entity(int salesD_id, int qty, int salesD_price, int salesD_amount, LocalDateTime saleD_datetime,
			boolean status, Item_Entity sDitem_id, SalesM_Entity salesMaster_id) {
		super();
		this.salesD_id = salesD_id;
		this.qty = qty;
		this.salesD_price = salesD_price;
		this.salesD_amount = salesD_amount;
		this.saleD_datetime = saleD_datetime;
		this.status = status;
		SDitem_id = sDitem_id;
		this.salesMaster_id = salesMaster_id;
	}

	public SalesD_Entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSalesD_id() {
		return salesD_id;
	}

	public void setSalesD_id(int salesD_id) {
		this.salesD_id = salesD_id;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getSalesD_price() {
		return salesD_price;
	}

	public void setSalesD_price(int salesD_price) {
		this.salesD_price = salesD_price;
	}

	public double getSalesD_amount() {
		return salesD_amount;
	}

	public void setSalesD_amount(double salesD_amount) {
		this.salesD_amount = salesD_amount;
	}

	public LocalDateTime getSaleD_datetime() {
		return saleD_datetime;
	}

	public void setSaleD_datetime(LocalDateTime saleD_datetime) {
		this.saleD_datetime = saleD_datetime;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Item_Entity getSDitem_id() {
		return SDitem_id;
	}

	public void setSDitem_id(Item_Entity sDitem_id) {
		SDitem_id = sDitem_id;
	}

	public SalesM_Entity getSalesMaster_id() {
		return salesMaster_id;
	}

	public void setSalesMaster_id(SalesM_Entity salesMaster_id) {
		this.salesMaster_id = salesMaster_id;
	}

	@Override
	public String toString() {
		return "SalesD_Entity [salesD_id=" + salesD_id + ", qty=" + qty + ", salesD_price=" + salesD_price
				+ ", salesD_amount=" + salesD_amount + ", saleD_datetime=" + saleD_datetime + ", status=" + status
				+ ", SDitem_id=" + SDitem_id + ", salesMaster_id=" + salesMaster_id + "]";
	}
	
	
	
	
	
	
}

