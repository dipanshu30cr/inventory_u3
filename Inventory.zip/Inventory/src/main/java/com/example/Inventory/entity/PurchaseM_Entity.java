package com.example.Inventory.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Purchase_Master")
public class PurchaseM_Entity 
{
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	int purchaseM_id;
	String invoice_no ;
	@Column(name = "date_time")                         // Mapping to the database columnjuhyu
    private LocalDateTime invoice_date;
	private LocalDateTime datetime;
	int total;
	boolean status;
	
	@ManyToOne
	@JoinColumn(name = "PM_Supplier_id")
    private SupplierM_Entity PM_Supplier_id;
	
	 @OneToMany(mappedBy = "PurchaseMasterId", cascade= CascadeType.ALL)
	    private List<Master_Purchase> PurchaseMasterId;

	public PurchaseM_Entity(int purchaseM_id, String invoice_no, LocalDateTime invoice_date, LocalDateTime datetime,
			int total, boolean status, SupplierM_Entity pM_Supplier_id) {
		super();
		this.purchaseM_id = purchaseM_id;
		this.invoice_no = invoice_no;
		this.invoice_date = invoice_date;
		this.datetime = datetime;
		this.total = total;
		this.status = status;
		PM_Supplier_id = pM_Supplier_id;
	}

	public PurchaseM_Entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPurchaseM_id() {
		return purchaseM_id;
	}

	public void setPurchaseM_id(int purchaseM_id) {
		this.purchaseM_id = purchaseM_id;
	}

	public String getInvoice_no() {
		return invoice_no;
	}

	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}

	public LocalDateTime getInvoice_date() {
		return invoice_date;
	}

	public void setInvoice_date(LocalDateTime invoice_date) {
		this.invoice_date = invoice_date;
	}

	public LocalDateTime getDatetime() {
		return datetime;
	}

	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public SupplierM_Entity getPM_Supplier_id() {
		return PM_Supplier_id;
	}

	public void setPM_Supplier_id(SupplierM_Entity pM_Supplier_id) {
		PM_Supplier_id = pM_Supplier_id;
	}

	@Override
	public String toString() {
		return "PurchaseM_Entity [purchaseM_id=" + purchaseM_id + ", invoice_no=" + invoice_no + ", invoice_date="
				+ invoice_date + ", datetime=" + datetime + ", total=" + total + ", status=" + status
				+ ", PM_Supplier_id=" + PM_Supplier_id + "]";
	}
	
	
	

}
