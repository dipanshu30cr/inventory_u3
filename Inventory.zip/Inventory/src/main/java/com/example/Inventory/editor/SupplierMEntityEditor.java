package com.example.Inventory.editor;

import java.beans.PropertyEditorSupport;

import com.example.Inventory.entity.SupplierM_Entity;
import com.example.Inventory.service.Supplier_Service;

public class SupplierMEntityEditor extends PropertyEditorSupport {

    private Supplier_Service supplierService;

    public SupplierMEntityEditor(Supplier_Service supplierService) {
        this.supplierService = supplierService;
    }

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
        if (text == null || text.isEmpty()) {
            setValue(null);
        } else {
            try {
                int id = Integer.parseInt(text);
                SupplierM_Entity supplier = supplierService.getSupplierById(id);
                setValue(supplier);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid supplier ID: " + text, e);
            }
        }
    }
}
